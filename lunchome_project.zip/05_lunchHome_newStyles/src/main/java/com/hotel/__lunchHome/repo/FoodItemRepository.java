package com.hotel.__lunchHome.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hotel.__lunchHome.model.FoodItem;

public interface FoodItemRepository extends JpaRepository<FoodItem, Long> {
}
