package com.hotel.__lunchHome.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotel.__lunchHome.model.FoodItem;
import com.hotel.__lunchHome.repo.FoodItemRepository;
import com.hotel.__lunchHome.service.FoodService;

@Service
public class FoodServiceImpl implements FoodService {

    @Autowired
    private FoodItemRepository foodRepo;

    @Override
    public List<FoodItem> getAllFood() {
        return foodRepo.findAll();
    }

    @Override
    public FoodItem getById(Long id) {
        return foodRepo.findById(id).orElse(null);
    }

    @Override
    public FoodItem save(FoodItem item) {
        return foodRepo.save(item);
    }

    @Override
    public void deleteById(Long id) {
        foodRepo.deleteById(id);
    }
}

