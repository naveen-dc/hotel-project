package com.hotel.__lunchHome.service;

import java.util.List;

import com.hotel.__lunchHome.model.FoodItem;

public interface FoodService {
    List<FoodItem> getAllFood();
    FoodItem getById(Long id);
    FoodItem save(FoodItem item);
    void deleteById(Long id);
}