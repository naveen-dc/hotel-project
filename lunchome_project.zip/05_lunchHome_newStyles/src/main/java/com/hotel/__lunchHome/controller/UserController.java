package com.hotel.__lunchHome.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hotel.__lunchHome.service.FoodService;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private FoodService foodService;

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("foodList", foodService.getAllFood());
        return "user_dashboard";
    }
}  