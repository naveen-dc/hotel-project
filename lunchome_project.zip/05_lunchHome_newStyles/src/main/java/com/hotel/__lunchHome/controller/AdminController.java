package com.hotel.__lunchHome.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.hotel.__lunchHome.model.FoodItem;
import com.hotel.__lunchHome.service.FoodService;



@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private FoodService foodService;

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("foodList", foodService.getAllFood());
        return "admin_dashboard";
    }

    @GetMapping("/add")
    public String addFoodForm(Model model) {
        model.addAttribute("foodItem", new FoodItem());
        return "add_food";
    }

    @PostMapping("/save")
    public String saveFood(@ModelAttribute FoodItem item) {
        foodService.save(item);
        return "redirect:/admin/dashboard";
    }

    @GetMapping("/edit/{id}")
    public String editFood(@PathVariable Long id, Model model) {
        model.addAttribute("foodItem", foodService.getById(id));
        return "add_food";
    }

    @GetMapping("/delete/{id}")
    public String deleteFood(@PathVariable Long id) {
        foodService.deleteById(id);
        return "redirect:/admin/dashboard";
    }
}