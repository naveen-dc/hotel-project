package com.hotel.__lunchHome.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.hotel.__lunchHome.repo.UserRepository;

import jakarta.servlet.http.HttpSession;
import com.hotel.__lunchHome.model.User;

@Controller
public class LoginController {

    @Autowired
    private UserRepository userRepo;

    @GetMapping("/")
    public String loginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password, HttpSession session, Model model) {
        if ("admin".equals(username) && "virat18".equals(password)) {
            session.setAttribute("role", "admin");
            return "redirect:/admin/dashboard";
        }

        User user = userRepo.findByUsername(username);
        if (user != null && user.getPassword().equals(password)) {
            session.setAttribute("role", "user");
            session.setAttribute("username", username);
            return "redirect:/user/dashboard";
        }

        model.addAttribute("error", "Invalid credentials!");
        return "login";
    }

    @GetMapping("/signup")
    public String signupPage(Model model) {
        model.addAttribute("user", new User());
        return "signup";
    }

//    @PostMapping("/register")
//    public String registerUser(@ModelAttribute User user, Model model) {
//        if (userRepo.findByUsername(user.getUsername()) != null) {
//            model.addAttribute("error", "Username already exists");
//            return "signup";
//        }
//        user.setRole("user");
//        userRepo.save(user);
//        return "redirect:/?signupSuccess=true";
//    }

    @PostMapping("/register")
    public String register(@ModelAttribute User user, Model model, HttpSession session) {
        if (userRepo.findByUsername(user.getUsername()) != null) {
            model.addAttribute("error", "Username already taken");
            return "signup";
        }

        userRepo.save(user);
        session.setAttribute("msg", "Account created successfully. Please log in.");
//        return "redirect:/";
        return "login";
    }
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }
}

