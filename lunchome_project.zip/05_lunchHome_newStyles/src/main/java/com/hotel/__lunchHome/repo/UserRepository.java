package com.hotel.__lunchHome.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hotel.__lunchHome.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByUsername(String username);
}
