package com.hotel.__lunchHome.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.hotel.__lunchHome.model.FoodItem;
import com.hotel.__lunchHome.service.FoodService;

import jakarta.servlet.http.HttpSession;


@Controller
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private FoodService foodService;

    @GetMapping("/view")
    public String viewCart(HttpSession session, Model model) {
        Map<Long, Integer> cart = (Map<Long, Integer>) session.getAttribute("cart");
        if (cart == null) cart = new HashMap<>();

        List<FoodItem> items = new ArrayList<>();
        double total = 0;

        for (Map.Entry<Long, Integer> entry : cart.entrySet()) {
            FoodItem item = foodService.getById(entry.getKey());
            if (item != null) {
                item.setNoOfPlates(entry.getValue());
                items.add(item);
                total += item.getCost() * entry.getValue();
            }
        }

        model.addAttribute("cartItems", items);
        model.addAttribute("total", total);
        return "cart";
    }

    @PostMapping("/add/{id}")
    public ResponseEntity<String> addToCart(@PathVariable Long id, @RequestParam int quantity, HttpSession session) {
        if (quantity <= 0) {
            return ResponseEntity.badRequest().body("Invalid quantity");
        }

        FoodItem food = foodService.getById(id);
        if (food == null || food.getNoOfPlates() < quantity) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Not enough stock");
        }

        Map<Long, Integer> cart = (Map<Long, Integer>) session.getAttribute("cart");
        if (cart == null) cart = new HashMap<>();

        int currentInCart = cart.getOrDefault(id, 0);
        if ((currentInCart + quantity) > food.getNoOfPlates()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Not enough stock available.");
        }

        cart.put(id, currentInCart + quantity);
        session.setAttribute("cart", cart);

        return ResponseEntity.ok("Added to cart");
    }

    @PostMapping("/checkout")
    public String checkout(HttpSession session) {
        Map<Long, Integer> cart = (Map<Long, Integer>) session.getAttribute("cart");
        if (cart == null) return "redirect:/user/dashboard";

        for (Map.Entry<Long, Integer> entry : cart.entrySet()) {
            FoodItem item = foodService.getById(entry.getKey());
            if (item != null) {
                int qty = entry.getValue();
                item.setNoOfPlates(item.getNoOfPlates() - qty);
                foodService.save(item);
            }
        }

        session.removeAttribute("cart");
        return "redirect:/user/dashboard?orderSuccess=true"; // ✅ append flag
    }
}
